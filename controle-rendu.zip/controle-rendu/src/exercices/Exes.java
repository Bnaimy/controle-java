package exercices;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Exes {

	public static void main(String[] args) {
		
		//question 1
		System.out.println(lePlusFrequent("coccucou"));
		//question2
		System.out.println(supprimerdoublons("ccooccoo"));
		//question3
		System.out.println(count("ccooccoo",2));

	}
	//exercice 1
	public static char lePlusFrequent(String chaine) {
		int max = 0;
		int compteur = 0;
		char temp = 't';
		for (int i = 0; i < chaine.length(); i++) {
			compteur = 1;
			for (int j = i + 1; j < chaine.length() - 1; j++) {
				if (chaine.charAt(i) == chaine.charAt(j))
					compteur++;
			}
			if (max < compteur) {
				max = compteur;
				temp = chaine.charAt(i);
			}
		}
		return temp;
	}
	
	//exercice 2
	public static String supprimerdoublons(String chaine)
	{
	    if ( chaine.length() <= 1 ) return chaine;
	    if( chaine.substring(1,2).equals(chaine.substring(0,1)) ) return supprimerdoublons(chaine.substring(1));
	    else return chaine.substring(0,1) + supprimerdoublons(chaine.substring(1));
	}
	
	//exercice 3
	public static int count(String chaine, int n){

        String[] tableau = chaine.split(" ");

        int cpt = 0;
        for (String s : tableau) {
            if(s.length() == n)
                cpt++;
        }

        return cpt;
	}
	
	//exercice 4 situe a la classe Etudiant
	
	//exercice 5
	
	//exercice 5
	Runnable message = new Runnable(){
		@Override
		public void run() {
			System.out.println("Bonjour, je suis un objet de type Runnable");
		}
	};
	
	//exercice 6
	
	public interface Predicate <T>{
			public boolean test(T t);
			
	}
	Predicate<String> predicate = new Predicate<String>() {
		@Override
		public boolean test(String s) {
			if(s.length()>10)
				return true ;
			return false;
		}
	};
	
	//exercice 7
	public <T> T premierelement(List<T> t) {
		return t.get(0);
	}
	
	//exercice 8
	public <T extends Comparable<T>> T mint(List<T> t) {
		List<T> sortedlist = new ArrayList<>(t);
		Collections.sort(sortedlist);
		return sortedlist.get(0);
	}
	
	
	
	
	
	
	
	
	
}